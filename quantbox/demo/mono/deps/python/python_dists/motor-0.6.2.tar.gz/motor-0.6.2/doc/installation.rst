Installation
============

Install Motor from PyPI_ with pip_::

  $ pip install motor

Pip automatically installs Motor's prerequisite packages.
See :doc:`requirements`.

.. _PyPI: http://pypi.python.org/pypi/motor

.. _pip: http://pip-installer.org
