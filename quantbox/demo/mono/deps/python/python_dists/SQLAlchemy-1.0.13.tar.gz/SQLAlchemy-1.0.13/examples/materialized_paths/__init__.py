"""Illustrates the "materialized paths" pattern for hierarchical data using the
SQLAlchemy ORM.

.. autosource::

"""
