"""
Two examples illustrating modifications to SQLAlchemy's attribute management
system.

.. autosource::

"""