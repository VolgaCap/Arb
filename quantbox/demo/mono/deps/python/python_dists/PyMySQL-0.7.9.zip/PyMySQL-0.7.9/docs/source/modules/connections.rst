:mod:`pymysql.connections`
==========================

.. automodule:: pymysql.connections

.. autoclass:: Connection
