:mod:`pymysql.cursors`
======================

.. automodule:: pymysql.cursors

.. autoclass:: Cursor
.. autoclass:: SSCursor
